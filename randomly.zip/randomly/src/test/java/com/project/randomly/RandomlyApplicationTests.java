package com.project.randomly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RandomlyApplicationTests {

	@Test
	void contextLoads() {
	}

}
